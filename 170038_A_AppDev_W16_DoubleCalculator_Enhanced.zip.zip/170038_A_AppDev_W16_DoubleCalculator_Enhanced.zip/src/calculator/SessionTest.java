/**
 * 
 */
package calculator;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author Vaibhav Kumar Mishra
 *
 */
public class SessionTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() {
		pass("Not yet implemented");
	}

	private void pass(String string) {
		// TODO Auto-generated method stub
		
	}

}
