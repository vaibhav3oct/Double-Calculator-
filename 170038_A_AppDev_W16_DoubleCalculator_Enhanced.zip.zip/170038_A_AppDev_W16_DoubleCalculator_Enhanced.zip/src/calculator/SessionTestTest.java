package calculator;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class SessionTestTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public final void testSetUpBeforeClass() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testSetUp() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testTest() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testObject() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetClass() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testHashCode() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testEquals() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testClone() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testToString() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testNotify() {
	pass("Not yet implemented"); // TODO
	}

	private void pass(String string) {
		// TODO Auto-generated method stub
		
	}

	@Test
	public final void testNotifyAll() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testWaitLong() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testWaitLongInt() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testWait() {
		pass("Not yet implemented"); // TODO
	}

	@Test
	public final void testFinalize() {
		pass("Not yet implemented"); // TODO
	}

}
